Font Sleuth 1.0

1-single-file/   fontsleuth.py - one runnable program. Python 3.12+:
                   pip install -r requirements.txt
                   python fontsleuth.py
2-source/        the full source, tests and build_exe.bat. On Windows, double-click build_exe.bat
                 to create dist\FontSleuth.exe (needs Python 3.12+ and internet access).
                 2-source/README.md explains how the app works and its limits.
